import { Simulator } from './components/Simulator';

function App() {
  return <Simulator />;
}

export default App;
